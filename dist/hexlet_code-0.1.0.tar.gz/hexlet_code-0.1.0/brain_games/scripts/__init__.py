def brain_games() -> str:
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    brain_games()
